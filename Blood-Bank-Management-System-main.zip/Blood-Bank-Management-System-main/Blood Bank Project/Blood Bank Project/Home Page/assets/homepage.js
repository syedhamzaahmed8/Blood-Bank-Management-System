document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("services").onclick = function () {
        window.location.href = "/connectivity/public/register.html"; // Change to the correct HTML file
    };
});